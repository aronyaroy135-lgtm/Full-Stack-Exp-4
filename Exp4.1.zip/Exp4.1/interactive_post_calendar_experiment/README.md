# Experiment: Interactive Calendar for Scheduling and Managing Posts

## Aim
To design and implement an interactive calendar interface for scheduling and managing social media posts.

## Objectives
1. Display posts on a monthly calendar.
2. Allow users to create, view, edit, and delete posts.
3. Store title, date, time, platform, status, and caption/notes.
4. Filter posts by status and platform.
5. Create a responsive interface for desktop and mobile browsers.

## Software Requirements
- HTML5, CSS3, JavaScript (ES6)
- A modern web browser (Chrome, Edge, Firefox, or Safari)
- No extra packages or internet connection required

## Theory
A content calendar organizes planned social posts by date, time, platform, and publication status. HTML defines the interface, CSS provides the layout and responsive styling, and JavaScript implements calendar navigation, filtering, validation, and CRUD (Create, Read, Update, Delete) operations. Browser `localStorage` retains the post list between sessions in the same browser profile.

## Procedure
1. Extract the ZIP archive.
2. Open `index.html` in a modern web browser.
3. Click **New post** or click a calendar date.
4. Enter a title, date, time, platform, status, and optional caption.
5. Click **Save post** and verify the post appears on the calendar and in the post list.
6. Click an existing post to edit or delete it.
7. Navigate months using the arrow buttons and test both filters.
8. Refresh the page to confirm posts are saved in local storage.

## Algorithm
1. Load saved posts from local storage; if none exist, display sample posts.
2. Determine the first day of the displayed month and render a six-week calendar grid.
3. For each date, show matching posts, sorted by time, with a color indicating status.
4. Render the post list according to the selected status and platform filters.
5. When a post is submitted, validate the required fields and add or update its record.
6. Save the updated post array to local storage and refresh the interface.
7. When a post is deleted, ask for confirmation, remove it, save, and refresh.

## Expected Output
A monthly interactive calendar with month navigation, colored post labels, filters, a post creation/editing form, and a list of scheduled content.

## Result
The interactive calendar interface was implemented. Users can create, view, edit, delete, and filter posts. Post records persist in the same browser through local storage.

## Limitations
- This front-end demonstration does not publish to social media platforms.
- Data is local to the current browser and is not synchronized across devices.
- Authentication, collaboration, and server-side storage are not included.

## Future Scope
Add login and role-based access, a server/database for synchronization, authorized platform APIs, notifications, recurring posts, drag-and-drop rescheduling, and analytics.

## Viva Questions
1. **What is a content calendar?** A date-based view used to organize planned posts.
2. **What is localStorage?** A browser API for saving key-value data locally between sessions.
3. **What does CRUD mean?** Create, Read, Update, and Delete.
4. **Why is CSS used?** To style the interface and support responsive layouts.
5. **Does this project publish posts online?** No; it is a front-end scheduling prototype.

## Files
- `index.html` — page structure and form
- `style.css` — styling and responsive layout
- `app.js` — calendar and post management logic
- `README.md` — experiment report and run instructions
