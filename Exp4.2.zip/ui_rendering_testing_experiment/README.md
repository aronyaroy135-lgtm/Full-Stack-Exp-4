# Experiment: Optimize Rendering Performance and Test Interactive UI Components

## Aim
To optimize rendering performance and implement testing strategies for interactive UI components.

## Objectives
1. Identify avoidable UI re-renders.
2. Apply memoization and stable callbacks to reduce unnecessary rendering work.
3. Measure render counts before and after optimization.
4. Test interactive behavior and accessibility-related basics.
5. Run automated unit/component tests.

## Software Requirements
- Node.js 18 or later
- npm
- A web browser

## Technologies
- React 18
- Vite
- Vitest
- React Testing Library
- @testing-library/user-event
- jsdom

## Experiment Theory
Interactive interfaces can become slow when components re-render unnecessarily, expensive computations repeat, or event handlers trigger excessive work. React's `memo`, `useMemo`, and `useCallback` can help when profiling shows that work is avoidable. They should not be applied indiscriminately: memoization adds complexity and is useful only when it prevents meaningful work.

Component tests should verify observable behavior rather than implementation details. React Testing Library encourages tests that interact with the UI as a user would. Vitest provides a fast test runner, while jsdom supplies a simulated DOM environment.

## Procedure
1. Install Node.js 18+.
2. Extract this ZIP and open a terminal in the project directory.
3. Run `npm install`.
4. Run `npm run dev` and open the URL printed by Vite.
5. Use the search field and increment/decrement buttons to interact with the UI.
6. Run `npm test` to execute component tests.
7. Run `npm run build` to verify the production build.
8. Compare the render counter in the app and inspect the memoized row behavior when changing the counter or search query.

## Implementation Notes
- `ProductList` filters the product data with `useMemo`.
- `ProductRow` uses `React.memo` so unrelated parent updates do not re-render every row when its props remain stable.
- `onToggle` is wrapped with `useCallback`.
- Tests cover rendering, filtering, interaction, and the fact that clicking a counter control does not cause memoized product rows to render again.
- The render counter is an educational diagnostic, not a substitute for React DevTools Profiler or real-user performance measurements.

## Expected Results
- The product list displays matching items as the user types.
- Increment and decrement buttons update the counter.
- Clicking the counter controls should not cause memoized product rows to re-render if their props are unchanged.
- Automated tests pass.
- The production build completes successfully.

## Result
After following the procedure, the learner should be able to demonstrate a small React interface with a measured rendering optimization and automated tests for interactive UI behavior.

## Conclusion
Rendering performance and component correctness can be improved by profiling, preventing avoidable work, and testing user-visible behavior. Optimization should be guided by evidence rather than adding memoization everywhere.

## Troubleshooting
- If `npm install` fails, check internet connectivity and Node/npm versions.
- If the test environment cannot find DOM globals, ensure `vitest.config.js` has `environment: 'jsdom'`.
- If a test fails after editing the UI, check accessible names and visible text before changing assertions.
