import React, { useCallback, useMemo, useState } from 'react';
import { PRODUCTS } from './data.js';
import { ProductRow } from './components/ProductRow.jsx';

export default function App() {
  const [query, setQuery] = useState('');
  const [counter, setCounter] = useState(0);
  const [selectedIds, setSelectedIds] = useState([]);
  const [showDiagnostics, setShowDiagnostics] = useState(false);

  const filteredProducts = useMemo(() => {
    const normalized = query.trim().toLowerCase();
    return PRODUCTS.filter((product) =>
      `${product.name} ${product.category}`.toLowerCase().includes(normalized),
    );
  }, [query]);

  const toggleProduct = useCallback((id) => {
    setSelectedIds((current) =>
      current.includes(id) ? current.filter((item) => item !== id) : [...current, id],
    );
  }, []);

  const selectedCount = selectedIds.length;

  return (
    <main className="page">
      <header className="hero">
        <p className="eyebrow">FRONTEND LAB · EXPERIMENT 01</p>
        <h1>Rendering performance & UI testing</h1>
        <p className="subtitle">
          Explore memoization, responsive interactions, and automated component tests.
        </p>
      </header>

      <section className="panel controls" aria-labelledby="counter-title">
        <div>
          <p className="eyebrow">INDEPENDENT STATE</p>
          <h2 id="counter-title">Interaction counter</h2>
          <p className="muted">Changing this value should not re-render unchanged product rows.</p>
        </div>
        <div className="counter-controls">
          <button type="button" aria-label="Decrease counter" onClick={() => setCounter((n) => n - 1)}>−</button>
          <output aria-label="Counter value" aria-live="polite">{counter}</output>
          <button type="button" aria-label="Increase counter" onClick={() => setCounter((n) => n + 1)}>+</button>
        </div>
      </section>

      <section className="panel" aria-labelledby="products-title">
        <div className="section-heading">
          <div>
            <p className="eyebrow">MEMOIZED LIST</p>
            <h2 id="products-title">Product catalogue</h2>
          </div>
          <span className="pill">{filteredProducts.length} items</span>
        </div>
        <label className="search-label" htmlFor="product-search">Search products</label>
        <input
          id="product-search"
          className="search-input"
          type="search"
          placeholder="Try “audio” or “keyboard”"
          value={query}
          onChange={(event) => setQuery(event.target.value)}
        />
        <p className="muted selection-summary" aria-live="polite">
          {selectedCount} selected
        </p>
        {filteredProducts.length ? (
          <ul className="product-list">
            {filteredProducts.map((product) => (
              <ProductRow
                key={product.id}
                product={product}
                selected={selectedIds.includes(product.id)}
                onToggle={toggleProduct}
              />
            ))}
          </ul>
        ) : (
          <p className="empty-state">No products match your search.</p>
        )}
      </section>

      <section className="panel diagnostics">
        <button
          className="text-button"
          type="button"
          aria-expanded={showDiagnostics}
          onClick={() => setShowDiagnostics((visible) => !visible)}
        >
          {showDiagnostics ? 'Hide' : 'Show'} optimization notes
        </button>
        {showDiagnostics && (
          <div className="diagnostic-content">
            <h2>Why these optimizations?</h2>
            <ul>
              <li><code>React.memo</code> can skip a row render when its props are unchanged.</li>
              <li><code>useMemo</code> caches the filtered list until the search query changes.</li>
              <li><code>useCallback</code> keeps the toggle handler reference stable.</li>
              <li>Use React DevTools Profiler to measure actual render duration in a production-like build.</li>
            </ul>
          </div>
        )}
      </section>
      <footer>Experiment: measure first, optimize selectively, and test user-visible behavior.</footer>
    </main>
  );
}
