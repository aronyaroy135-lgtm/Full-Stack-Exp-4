import React from 'react';

export const ProductRow = React.memo(function ProductRow({ product, selected, onToggle }) {
  return (
    <li className="product-row">
      <label className="product-label">
        <input
          type="checkbox"
          checked={selected}
          onChange={() => onToggle(product.id)}
          aria-label={`Select ${product.name}`}
        />
        <span className="product-name">{product.name}</span>
      </label>
      <span className="category">{product.category}</span>
      <strong>₹{product.price.toLocaleString('en-IN')}</strong>
    </li>
  );
});
