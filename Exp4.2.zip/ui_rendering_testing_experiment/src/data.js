export const PRODUCTS = [
  { id: 1, name: 'Wireless Mouse', category: 'Accessories', price: 799 },
  { id: 2, name: 'Mechanical Keyboard', category: 'Accessories', price: 3499 },
  { id: 3, name: 'USB-C Hub', category: 'Connectivity', price: 1599 },
  { id: 4, name: 'Laptop Stand', category: 'Workspace', price: 1299 },
  { id: 5, name: 'HD Webcam', category: 'Accessories', price: 2299 },
  { id: 6, name: 'Noise-Cancelling Headphones', category: 'Audio', price: 5999 },
  { id: 7, name: 'Portable SSD', category: 'Storage', price: 4299 },
  { id: 8, name: 'Desk Lamp', category: 'Workspace', price: 999 },
];
