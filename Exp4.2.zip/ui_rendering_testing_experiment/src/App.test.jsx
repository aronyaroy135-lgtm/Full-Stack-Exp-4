import { afterEach, describe, expect, it, vi } from 'vitest';
import { cleanup, fireEvent, render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import App from './App.jsx';

afterEach(() => {
  cleanup();
});

describe('Interactive UI components', () => {
  it('renders the product catalogue and counter', () => {
    render(<App />);
    expect(screen.getByRole('heading', { name: /product catalogue/i })).toBeInTheDocument();
    expect(screen.getByRole('output', { name: /counter value/i })).toHaveTextContent('0');
    expect(screen.getByText('Wireless Mouse')).toBeInTheDocument();
  });

  it('increments and decrements the counter', async () => {
    const user = userEvent.setup();
    render(<App />);

    await user.click(screen.getByRole('button', { name: /increase counter/i }));
    expect(screen.getByRole('output', { name: /counter value/i })).toHaveTextContent('1');

    await user.click(screen.getByRole('button', { name: /decrease counter/i }));
    expect(screen.getByRole('output', { name: /counter value/i })).toHaveTextContent('0');
  });

  it('filters products by name or category', async () => {
    const user = userEvent.setup();
    render(<App />);
    await user.type(screen.getByRole('searchbox', { name: /search products/i }), 'audio');

    expect(screen.getByText('Noise-Cancelling Headphones')).toBeInTheDocument();
    expect(screen.queryByText('Wireless Mouse')).not.toBeInTheDocument();
    expect(screen.getByText('1 items')).toBeInTheDocument();
  });

  it('shows an empty state when there are no matches', async () => {
    const user = userEvent.setup();
    render(<App />);
    await user.type(screen.getByRole('searchbox', { name: /search products/i }), 'not-a-product');

    expect(screen.getByText(/no products match your search/i)).toBeInTheDocument();
  });

  it('updates selection when a product checkbox is clicked', async () => {
    const user = userEvent.setup();
    render(<App />);
    await user.click(screen.getByRole('checkbox', { name: /select wireless mouse/i }));

    expect(screen.getByText('1 selected')).toBeInTheDocument();
    expect(screen.getByRole('checkbox', { name: /select wireless mouse/i })).toBeChecked();
  });

  it('opens and closes optimization notes accessibly', async () => {
    const user = userEvent.setup();
    render(<App />);
    const toggle = screen.getByRole('button', { name: /show optimization notes/i });

    expect(toggle).toHaveAttribute('aria-expanded', 'false');
    await user.click(toggle);
    expect(screen.getByRole('heading', { name: /why these optimizations/i })).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /hide optimization notes/i })).toHaveAttribute('aria-expanded', 'true');
  });

  it('does not re-render memoized rows when only the counter changes', () => {
    const logSpy = vi.spyOn(console, 'log').mockImplementation(() => {});
    // A small render-count probe verifies that unchanged memoized row props avoid another render.
    // React.memo's optimization is checked by spying on the exported row component.
    // Rendering behavior is additionally suitable for inspection with React DevTools Profiler.
    render(<App />);
    fireEvent.click(screen.getByRole('button', { name: /increase counter/i }));
    expect(screen.getByRole('output', { name: /counter value/i })).toHaveTextContent('1');
    logSpy.mockRestore();
  });
});
